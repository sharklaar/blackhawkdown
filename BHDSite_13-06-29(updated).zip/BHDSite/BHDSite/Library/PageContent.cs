﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHDSite.Library
{
    public class PageContent
    {
        public string PageTitle { get; set; }
        public string PageText { get; set; }
        public string PageImageUrl { get; set; }
    }
}