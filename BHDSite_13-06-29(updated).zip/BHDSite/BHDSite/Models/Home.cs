﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHDSite.Models
{
    public class Home
    {
        public string HomePageTitle { get; set; }
        public string HomePageText { get; set; }
    }
}