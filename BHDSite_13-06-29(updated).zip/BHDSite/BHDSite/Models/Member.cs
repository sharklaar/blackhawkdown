﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BHDSite.Models
{
    public class Member
    {
        public string BenTitle { get; set; }
        public string BenText { get; set; }
        public string BenImage { get; set; }

        public string NorbTitle { get; set; }
        public string NorbText { get; set; }
        public string NorbImage { get; set; }

        public string AndyTitle { get; set; }
        public string AndyText { get; set; }
        public string AndyImage { get; set; }

        public string SharkTitle { get; set; }
        public string SharkText { get; set; }
        public string SharkImage { get; set; }

        public string HemyTitle { get; set; }
        public string HemyText { get; set; }
        public string HemyImage { get; set; }

        public string BandTitle { get; set; }
        public string BandText { get; set; }
        public string BandImage { get; set; }
    }
}